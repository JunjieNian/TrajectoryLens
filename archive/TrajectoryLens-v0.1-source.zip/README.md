# Trajectory Lens

A small, offline-capable research workspace for comparing the **process** behind agent outcomes. Part of [Junjie Nian's personal website](https://junjienian.com), inspired by his work on TraceGraph and SliceGraph.

**Online:** [junjienian.com/tools/trajectory-lens/](https://junjienian.com/tools/trajectory-lens/)

The interface follows the existing website: an ivory background, burgundy accents, Newsreader headings, DM Sans body text, and a restrained reading layout. The offline edition includes the shared stylesheet and favicon; system fonts provide a fallback when the optional web fonts cannot load.

English is the default interface language. Use **中文 / EN** to switch without losing loaded data or the current selection. Original imported records are never translated.

## Open the app

Open `dist/index.html` in a modern browser. Keep the other files in `dist/` beside it. No installation, API key, build, or server is needed for the offline edition.

The online edition at the address above contains the same client-side app. Imported trajectory files are parsed in the browser and remain in page memory; they are not uploaded. Refreshing the page clears an imported dataset. Export anything you want to keep. The offline edition keeps its styles and scripts local; links to the personal website and source repositories open their online addresses.

## A two-minute tour

1. Start with the clearly labeled teaching example. Compare a path that repeats a failed test with one that repairs the issue. Inspect the repeated state and its separate original records.
2. Click a graph node or a replay step. Use the occurrence buttons to move to that state in another run. The text panel always shows a concrete record, not a generated summary.
3. Open **Released research**. Compare the four process families for `gpqa-64`, then switch to `hmmt25-15`. Inspect state visits and the complete transition matrix.
4. Import your own JSON or JSONL, then export a Markdown report, standardized JSON, or an editable SVG of the current state graph.

## Recommended input

```json
{
  "name": "Boundary-condition experiment",
  "description": "Two runs on the same task",
  "source": "Experiment batch 2026-09-29",
  "runs": [
    {
      "id": "run-1",
      "model": "agent-a",
      "outcome": "success",
      "steps": [
        {
          "state": "inspect:transform.py",
          "label": "Inspect transform.py",
          "text": "Action and observation exactly as recorded",
          "tokens": 240,
          "duration_ms": 1300
        }
      ]
    }
  ]
}
```

`outcome` can be `success`, `failure`, or `unknown`. Outcomes come from explicit input fields, not from keywords in the text. Token and duration values are optional nonnegative numbers. Totals include only recorded step values; incomplete coverage is disclosed.

The importer also accepts:

- A JSON array of run objects.
- JSONL with one complete run object per nonempty line.
- A single run object with `steps`, `trajectory`, or `messages`.
- String steps and simple action/observation records.
- Simple OpenAI-style messages and tool calls. This is a best-effort record adapter, not a semantic state extractor.

If a step supplies `text`, it is the authoritative evidence text and is preserved exactly, including whitespace. Otherwise, supplied `thought`, `content`, action/tool-call arguments, and `observation` are shown together, with source labels when multiple fields are present. Canonical JSON export preserves that combined evidence without duplicating it on reimport.

Limits: 10 MB of text, 100 runs, 2,000 steps per run, 20,000 steps in total. The shared graph renders up to 100 unique states. Larger state sets retain replay, records, metrics, and report export; SVG export is unavailable when the graph is not rendered.

## What alignment means

The workspace uses exact identifiers, in this order:

1. An explicit `state` or `state_id`.
2. The complete, sorted, deduplicated `keys` set.
3. Normalized action/tool text, including arguments.
4. Normalized full text.

Explicit IDs and keys preserve case and whitespace. Fallback text lowercases and collapses whitespace. Different matching modes never merge. Long labels are shortened for display, while full identities remain intact.

For meaningful comparisons, supply stable `state` annotations or the exact `keys` emitted by your pipeline. Unannotated raw text often creates many distinct states. If two semantically different records share an explicit ID, the tool follows that annotation; it does not independently verify equivalence.

The graph's horizontal position is the mean relative step index of all visits to a state. Vertical position is a display arrangement. Neither coordinate is an activation embedding or a measured distance.

## Metrics

- **Revisit:** any visit after the first occurrence of the same exact state within one run. Revisit rate = revisits / all steps.
- **State overlap:** Jaccard of the two sets of exact state identities, `intersection / union`.
- **First divergence:** the first unequal state after the shared exact prefix; a run ending also counts as divergence.
- **Tokens:** the sum of recorded step-level values. Run-level token totals are not distributed across steps.

A revisit can be necessary verification or productive exploration. It is not automatically a mistake, trap, or wasted work. State-set overlap ignores ordering; it does not prove strategy equivalence.

## Released SliceGraph evidence

The two bundled cases are exact parsed copies of public files pinned to commit:

`3947116b2942a87974bc76ccddab3fcaae5a0777`

- [GPQA case](https://github.com/JunjieNian/SliceGraph/blob/3947116b2942a87974bc76ccddab3fcaae5a0777/results/case_studies/qwen3_4b_inst__gpqa__gpqa-64__family_kernels.json)
- [HMMT25 case](https://github.com/JunjieNian/SliceGraph/blob/3947116b2942a87974bc76ccddab3fcaae5a0777/results/case_studies/qwen3_4b_think__hmmt25__hmmt25-15__family_kernels.json)

They contain **aggregate, Laplace-smoothed typed-state transition kernels**, not individual trajectories. The released families contain correct runs only, with at least three members; they may not cover every correct run in the problem cell. The full problem's correct/wrong counts are kept separate from family coverage.

For non-EOS states, each visit produces one counted outgoing transition. With `alpha = 0.5` and `N` states, each target's smoothing baseline is `0.5 / (visits + 0.5*N)`. The graph hides zero-visit sources, forced EOS source self-loops, and edges at the smoothing baseline; it also applies the chosen probability threshold. The complete matrix retains all published values. EOS rows are forced absorbing rows. A small probability of `EOS_wrong` in a correct-only family can be smoothing mass, not an observed failure.

Probabilities were rounded to four decimal places in the source. The display uses a small tolerance for the smoothing filter. TV values are the original reported distances between family kernels; they are not success rates or causal effects. Source URLs, the pinned revision, and original-file SHA256 hashes are preserved in `released-data.js`.

The teaching trajectories, their outcomes, annotations, and costs are hand-constructed and explicitly labeled. They are not paper results.

## Research relationship

This workspace is inspired by [TraceGraph](https://junjienian.com/research/tracegraph.html) and [SliceGraph](https://junjienian.com/research/slicegraph.html). It does not reproduce mutual-kNN, biconnected-component extraction, activation representations, reward diffusion, or process-family clustering. Its role is transparent inspection of supplied records and released evidence.

## Editable source

- `dist/index.html`: interface and dialogs.
- `dist/style.css`: responsive visual system.
- `dist/app.js`: graph, replay, imports, exports, and released-evidence view.
- `dist/engine.js`: dependency-free normalization and exact-state analysis.
- `dist/demo.js`: clearly labeled illustrative data.
- `dist/released-data.js`: pinned public data and provenance.
- `dist/i18n.js`: English/Chinese interface text and language switching.
- `dist/shared.css` and `dist/favicon.svg`: copies of the personal website's shared assets for the offline edition.

The engine is usable in Node through `require('./dist/engine.js')`. Its public methods are `parse`, `normalize`, `analyze`, `firstDivergence`, `toCanonical`, `exportJSON`, and `exportMarkdown`. Use `exportJSON` for round-trip-safe canonical data.

In browsers that support WebMCP, the page offers two optional tools: read the loaded dataset's metric summary and navigate to an existing run/step. Neither imports a file or sends data to a remote service.

## 中文简要说明

正式地址：[junjienian.com/tools/trajectory-lens/](https://junjienian.com/tools/trajectory-lens/)。界面沿用个人网站的米白底、酒红色和简约排版。默认英文，可切换中文；原始实验记录不翻译。打开 `dist/index.html` 即可离线使用，导入的数据只保留在本页内存中，刷新会清空。建议给实验步骤提供稳定的 `state` 或 `keys`，再比较路径、重复访问和原文证据。公开研究样例是固定版本的真实汇总数据；教学轨迹为手工构造，二者在界面中明确区分。

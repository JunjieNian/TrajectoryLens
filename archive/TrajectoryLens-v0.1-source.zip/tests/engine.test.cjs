'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const vm = require('node:vm');
const fs = require('node:fs');
const path = require('node:path');
const engineFile = path.resolve(__dirname, '../dist/engine.js');
const Lens = require(engineFile);

test('explicit identity, sorted exact key sets and unclipped fallback identity', () => {
  const longPrefix = 'a'.repeat(110);
  const data = Lens.normalize({ runs: [{ id: 'one', steps: [
    { keys: ['beta', 'alpha'], text: 'First wording' },
    { keys: ['alpha', 'beta', 'alpha'], text: 'Different wording' },
    { state: 'Case', keys: ['alpha', 'beta'] },
    { state: 'case' },
    { text: longPrefix + ' ending 1' },
    { text: longPrefix + ' ending 2' },
    { text: '  exact \n TEXT ' },
    { text: 'exact text' }
  ] }] });
  assert.equal(data.runs[0].steps[0].state, data.runs[0].steps[1].state);
  assert.notEqual(data.runs[0].steps[2].state, data.runs[0].steps[3].state);
  assert.notEqual(data.runs[0].steps[4].state, data.runs[0].steps[5].state);
  assert.equal(data.runs[0].steps[6].state, data.runs[0].steps[7].state);
  assert.ok(data.runs[0].steps[4].label.length <= 96);
  assert.equal(Lens.analyze(data).totals.uniqueStates, 6);
  assert.deepEqual(data.matching.counts, { explicit: 2, keys: 2, action: 0, text: 4 });
});

test('rejects nonsense, duplicates, invalid outcomes and invalid numeric values', () => {
  for (const raw of [{}, { runs: [] }, { steps: [] }, { steps: [{}] }, { steps: [{ label: 'pretty but empty' }] }, { runs: [{ steps: ['a'] }, { id: 'run-1', steps: ['b'] }] }, { steps: ['a'], outcome: 'maybe' }]) {
    assert.throws(() => Lens.normalize(raw));
  }
  for (const value of [-1, Infinity, NaN, '12']) {
    assert.throws(() => Lens.normalize({ steps: [{ text: 'a', tokens: value }] }), /finite, nonnegative/);
    assert.throws(() => Lens.normalize({ steps: [{ text: 'a', duration_ms: value }] }), /finite, nonnegative/);
  }
  assert.throws(() => Lens.normalize({ steps: [{ text: 'a', usage: { input_tokens: -1 } }] }), /nonnegative/);
  assert.throws(() => Lens.normalize({ tokens: -1, steps: ['a'] }), /nonnegative/);
  assert.throws(() => Lens.analyze({ steps: [{ state: 'a', tokens: 1e308 }, { state: 'b', tokens: 1e308 }] }), /finite/);
  assert.throws(() => Lens.normalize({ steps: [{ text: 'a', keys: [1] }] }), /keys/);
  assert.throws(() => Lens.normalize({ runs: Array.from({ length: 101 }, (_, i) => ({ id: i, steps: ['a'] })) }), /At most 100/);
  assert.throws(() => Lens.normalize({ steps: Array.from({ length: 2001 }, () => 'a') }), /exceeds 2000/);
  assert.throws(() => Lens.normalize({ runs: Array.from({ length: 11 }, (_, i) => ({ id: i, steps: Array.from({ length: 2000 }, () => 'a') })) }), /20000 total/);
});

test('loops retain transition multiplicity, exact overlap and prefix divergence', () => {
  const data = Lens.normalize({ runs: [
    { id: 'loop', model: 'A', outcome: 'failure', steps: [{ state: 'start' }, { state: 'search' }, { state: 'start' }, { state: 'search' }, { state: 'done' }] },
    { id: 'direct', model: 'B', outcome: 'success', steps: [{ state: 'start' }, { state: 'search' }, { state: 'done' }] }
  ] });
  const result = Lens.analyze(data);
  assert.equal(result.nodes.length, 3);
  assert.equal(result.totals.transitions, 6);
  assert.equal(result.perRun[0].revisits, 2);
  assert.equal(result.perRun[0].revisitRate, 0.4);
  assert.equal(result.overlaps[0].jaccard, 1);
  assert.equal(result.overlaps[0].intersection, 3);
  const startId = result.runPaths.loop[0], searchId = result.runPaths.loop[1];
  assert.equal(result.edges.find(e => e.source === startId && e.target === searchId).count, 3);
  assert.equal(Lens.firstDivergence(data, 'loop', 'direct').prefixLength, 2);
  assert.equal(Lens.firstDivergence(data, 'loop', 'direct').reason, 'state-mismatch');
  assert.equal(Lens.firstDivergence(data, 'direct', 'direct').identical, true);
  assert.throws(() => Lens.firstDivergence(data, 'missing', 'direct'), /existing/);
});

test('partial tokens remain visibly incomplete; zero is observed and no count is null', () => {
  const data = Lens.normalize({ runs: [
    { id: 'partial', steps: [{ state: 'a', tokens: 0 }, { state: 'b' }, { state: 'c', usage: { input_tokens: 10, output_tokens: 2 } }] },
    { id: 'unknown', steps: [{ state: 'a' }] }
  ] });
  const result = Lens.analyze(data);
  assert.equal(result.perRun[0].totalTokens, 12);
  assert.equal(result.perRun[0].tokensComplete, false);
  assert.equal(result.perRun[0].knownTokenSteps, 2);
  assert.equal(result.perRun[1].totalTokens, null);
  assert.equal(result.totals.knownTokenSteps, 2);
  assert.equal(result.totals.tokensComplete, false);
  assert.ok(data.warnings.some(w => w.includes('2 of 4 steps')));
});

test('JSONL line errors, BOM, messages, tool arguments and outcome remain grounded', () => {
  const data = Lens.parse('\ufeff{"id":"a","messages":[{"role":"user","content":[{"type":"text","text":"Find paper"}]},{"role":"assistant","content":null,"tool_calls":[{"id":"call-1","function":{"name":"search","arguments":"{\\"q\\":\\"risa\\"}"}}]}]}\n{"id":"b","trajectory":[{"action":"search({\\"q\\":\\"risa\\"})","observation":"Found"},{"text":"Task completed successfully"}]}\n', 'trace.jsonl');
  assert.equal(data.name, 'trace');
  assert.equal(data.runs[0].steps[1].state, data.runs[1].steps[0].state);
  assert.equal(data.runs[1].outcome, 'unknown');
  assert.equal(data.matching.counts.action, 2);
  assert.throws(() => Lens.parse('{"steps":["a"]}\n{broken}\n', 'bad.jsonl'), /line 2/);
  assert.throws(() => Lens.parse('', 'empty.json'), /empty/);
  assert.throws(() => Lens.parse('{"messages":[]}', 'empty.json'), /nonempty/);
});

test('raw trajectory evidence retains thought, action and observation without changing action identity', () => {
  const thought = '  Inspect the boundary condition first.\nThen patch.  ';
  const action = '  python -c "print(transform([]))"\n';
  const observation = '\nTraceback:\n  IndexError: list index out of range\n';
  const data = Lens.normalize({ trajectory: [{ thought, action, observation }] });
  const step = data.runs[0].steps[0];
  assert.equal(step.text, 'THOUGHT:\n' + thought + '\n\nACTION:\n' + action + '\n\nOBSERVATION:\n' + observation);
  assert.equal(step.matchingMode, 'action');
  assert.equal(step.state, Lens.normalize({ steps: [{ action }] }).runs[0].steps[0].state);
  assert.equal(step.__lensOrigin.action, action);
  const roundtrip = Lens.parse(Lens.exportJSON(data), 'evidence.json');
  assert.equal(roundtrip.runs[0].steps[0].text, step.text);
  assert.equal(roundtrip.runs[0].steps[0].state, step.state);
  assert.equal(roundtrip.runs[0].steps[0].text.split('ACTION:').length, 2);
});

test('assistant content and tool-call argument strings remain available as evidence', () => {
  const content = 'I will read the failing test.\n  Keep the original indentation.';
  const argumentsText = '{\n  "path": "tests/test_transform.py",\n  "mode": "r"\n}';
  const data = Lens.normalize({ messages: [{ role: 'assistant', content, tool_calls: [
    { id: 'transport-1', type: 'function', function: { name: 'read_file', arguments: argumentsText } }
  ] }] });
  const step = data.runs[0].steps[0];
  assert.equal(step.text, 'CONTENT:\n' + content + '\n\nACTION:\nread_file(' + argumentsText + ')');
  assert.ok(step.text.includes(argumentsText));
  assert.equal(step.matchingMode, 'action');
  const roundtrip = Lens.parse(Lens.exportJSON(data), 'message.json');
  assert.equal(roundtrip.runs[0].steps[0].text, step.text);
  assert.equal(roundtrip.runs[0].steps[0].state, step.state);
});

test('canonical text is authoritative and preserves whitespace through export and reimport', () => {
  const text = '\n  Original evidence\n\n  with indentation.  \n';
  const data = Lens.normalize({ name: 'Canonical evidence', steps: [{ text, action: 'echo evidence', thought: 'Do not append this', observation: 'Already represented in text' }] });
  assert.equal(data.runs[0].steps[0].text, text);
  const once = Lens.exportJSON(data);
  const twice = Lens.exportJSON(Lens.parse(once, 'canonical.json'));
  assert.equal(twice, once);
  assert.equal(Lens.parse(twice, 'canonical.json').runs[0].steps[0].text, text);
  assert.equal(Lens.normalize({ steps: [{ state: 'empty-evidence', text: '' }] }).runs[0].steps[0].text, '');
  assert.throws(() => Lens.normalize({ steps: [{ text: ' \n\t ' }] }), /no usable/);
  assert.equal(Lens.normalize({ steps: [{ content: text }] }).runs[0].steps[0].text, text);
});

test('one-ended prefix, singleton progress, safe run IDs and stable state IDs', () => {
  const data = Lens.normalize({ runs: [
    { id: '__proto__', steps: [{ state: 'a' }] },
    { id: 'long', steps: [{ state: 'a' }, { state: 'b' }] }
  ] });
  const result = Lens.analyze(data);
  assert.equal(result.runPaths.__proto__.length, 1);
  assert.equal(Lens.firstDivergence(data, '__proto__', 'long').reason, 'run-ended');
  assert.equal(result.nodes.find(n => n.label === 'a').progress, 0);
  const reversed = Lens.analyze(Lens.normalize({ runs: [{ id: 'long', steps: [{ state: 'a' }, { state: 'b' }] }, { id: '__proto__', steps: [{ state: 'a' }] }] }));
  assert.equal(result.nodes.find(n => n.label === 'a').id, reversed.nodes.find(n => n.label === 'a').id);
  const subset = Lens.analyze({ steps: [{ state: 'b' }] });
  assert.equal(result.nodes.find(n => n.label === 'b').id, subset.nodes[0].id);
});

test('Markdown report discloses denominators, incomplete coverage and escapes imported markup', () => {
  const data = Lens.normalize({ name: '<img src=x onerror=alert(1)>', source: '[bad](javascript:alert(1))', runs: [
    { id: 'a|<script>', model: '**model**', outcome: 'failure', steps: [{ state: 'x', tokens: 10 }, { state: 'x' }] },
    { id: 'b', steps: [{ state: 'x' }, { state: 'y' }] }
  ] });
  const report = Lens.exportMarkdown(data);
  assert.ok(report.includes('1/2 incomplete'));
  assert.ok(report.includes('Revisit rate divides revisits by all steps'));
  assert.ok(report.includes('50.0%'));
  assert.ok(report.includes('not semantic matching'));
  assert.ok(report.includes('&lt;img'));
  assert.ok(!report.includes('<script>'));
  assert.ok(!report.includes('[bad](javascript:'));
  const canonical = Lens.parse(Lens.exportJSON(data), 'roundtrip.json');
  assert.deepEqual(canonical.runs.map(r => r.steps.map(s => s.state)), data.runs.map(r => r.steps.map(s => s.state)));
  const mixed = Lens.normalize({ steps: [{ state: 2 }, { keys: ['B', 'a'] }, { action: 'Call with A', observation: 'result' }, { text: 'Exact text' }] });
  const roundtrip = Lens.parse(Lens.exportJSON(mixed), 'mixed.json');
  assert.deepEqual(roundtrip.matching.counts, mixed.matching.counts);
  assert.deepEqual(roundtrip.runs[0].steps.map(s => s.state), mixed.runs[0].steps.map(s => s.state));
});

test('browser build exposes global without requiring modules or DOM', () => {
  const context = vm.createContext({});
  vm.runInContext(fs.readFileSync(engineFile, 'utf8'), context);
  assert.equal(typeof context.LensEngine.normalize, 'function');
  assert.equal(context.LensEngine.analyze(context.LensEngine.normalize({ steps: ['a', 'a'] })).totals.revisits, 1);
});
